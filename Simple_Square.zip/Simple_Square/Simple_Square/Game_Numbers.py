from Vector import Vector

# Screen valuees
screen_color = (100, 149, 237)
screen_width = 800
screen_height = 600
screen_size = Vector(screen_width, screen_height)

frame_rate = 60

# Player values
player_size = 25
player_color = (255, 0, 0)
player_speed = 1

